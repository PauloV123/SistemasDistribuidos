import time
import ctypes
from multiprocessing import Process, Manager
from multiprocessing.sharedctypes import Array

primeiroDigito_CPF = [10, 9, 8, 7, 6, 5, 4, 3, 2] 
segundoDigito_CPF = [11, 10, 9, 8, 7, 6, 5, 4, 3, 2]
primeiroDigito_CNPJ = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
segundoDigito_CNPJ = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]

NUM_PROCESSOS = 4

#Gera o arquivo com TODOS os outputs
def arquivoResposta(listaCPFs, listaCNPJs):
    
    with open('RESULTADO_BASEPROJETO.txt', 'w') as arq: #Vai gerar o arquivo na pasta com o nome RESULTADO_BASEPROJETO
        for cpf in listaCPFs:   #Vai preencher com os CPFs
            arq.write(f'{cpf}\n')
            
        for cnpj in listaCNPJs:  #Vai preencher com os CNPJs
            arq.write(f'{cnpj}\n')

#------------------------------------------------------------------------------------------------------
#Aqui é feito o calculo do digito verificador do CPF e do CNPF
def calculaDigitoVerificador(dado, peso1, peso2):

    somaDoPrimeiroDigito = 0
    for valorDoDado, peso in zip(dado, peso1):
        somaDoPrimeiroDigito += int(valorDoDado) * peso

#Aqui é definido o valor do primeiro dígito, se a soma/11 < 2 o valor é 0,
#se não ele vai ser 11 - soma/11

    if somaDoPrimeiroDigito % 11 < 2: 
        primeiroDigito = 0
    else:
        primeiroDigito = 11 - (somaDoPrimeiroDigito % 11)

    dado = dado + str(primeiroDigito)

#Mesmo esquema para o segundo digito, única diferença entra as lógicas é o peso

    somaDoSegundoDigito = 0
    for valorDoDado, peso in zip(dado, peso2):
        somaDoSegundoDigito += int(valorDoDado) * peso

    if somaDoSegundoDigito % 11 < 2:
        segundoDigito = 0
    else:
        segundoDigito = 11 - (somaDoSegundoDigito % 11)

    dado = dado + str(segundoDigito)
    return dado

#------------------------------------------------------------------------------------------------------
#Aqui vai ser separado os CPFs dos CNPJs
def separacaoDeValores(dados, thread_number, cpf_completo, cnpj_completo):    
    slice_por_thread = int(len(dados)/NUM_PROCESSOS)
    inicio = int(thread_number * slice_por_thread)
    for dado in dados[inicio:inicio + slice_por_thread]:
        #Sabendo q um CPF tem 9 campos e um CNPJ tem 12 a separação vai ser feita com base no tamanho dos valores da linha
        if len(dado) == 9:
            cpf_completo.append(calculaDigitoVerificador(dado, primeiroDigito_CPF, segundoDigito_CPF))
        elif len(dado) == 12:
            cnpj_completo.append(calculaDigitoVerificador(dado, primeiroDigito_CNPJ, segundoDigito_CNPJ))
        else:
            print("ERRO")

#------------------------------------------------------------------------------------------------------
#Lê as linhas do BASEPROJETO.txt e retorna uma lista de cada linha
def listaBaseProjeto():
    with open("BASEPROJETO.txt", 'r') as arq: #Aqui vai abrir o arquivo 
        listaLinhas = [line.strip(' ').strip('\n') for line in arq.readlines()] #Aqui ele está montando a lista com todas as linhas do txt 

    return listaLinhas

#------------------------------------------------------------------------------------------------------
def main():  
    start = time.time()
    print("1º passo - Listar os valores do BASEPROJETO.txt ")
    dados = listaBaseProjeto()

    print("---------------------------------------------------")
    print("2º passo - Calcular os digitos verificadores")
    with Manager() as manager:
        cpf_completo = manager.list()
        cnpj_completo = manager.list()

        processes = []
        for i in range(NUM_PROCESSOS):
            p = Process(target=separacaoDeValores, args=(dados, i, cpf_completo, cnpj_completo)) 
            p.start()
            processes.append(p)
        for p in processes:
            p.join()
            
        fimDoprocessamento = (time.time() - start)
        print(f'Tempo cálculo dos digitos verificadores: {fimDoprocessamento:.2f} segundos')
        
        cpf_completo = list(cpf_completo)
        cnpj_completo = list(cnpj_completo)

    print("---------------------------------------------------")
    print("3º passo - Gerar o arquivo com os resultados")
    arquivoResposta(cpf_completo, cnpj_completo)
    fimDaGeracaoDaResposta = (time.time() - start - fimDoprocessamento)
    print(f'Tempo de geração do arquivo com a resposta: {fimDaGeracaoDaResposta:.2f} segundos')
    
    fim = (time.time() - start)
    print("---------------------------------------------------")
    print("Arquivo com os resultados gerado!")
    print(f'Tempo total: {fim:.2f} segundos')
    
if __name__ == "__main__":
    main()
